package com.kosa.kapple.domain;

import lombok.Data;

@Data
public class DepartmentVO {
	private String dept_no;
	private String dept_name;
	private Long TOO;//table of organization
	private String ext_phone;
}
