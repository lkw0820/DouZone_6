package com.kosa.kapple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KappleApplicationTests {

    @Test
    void contextLoads() {
    }

}
